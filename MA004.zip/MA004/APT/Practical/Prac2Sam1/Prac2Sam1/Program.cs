﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac2Sam1
{
    class Program
    {
        Program()
        {

            int n, n1 = 0, a = 0, f = 1;
            string[] s = new string[100];
            string[] s1 = new string[100];
            string[] s2 = new string[100];
            int[] c = new int[100];
            int k = 0;
            Console.WriteLine("Enter No Of String : ");
            n = Int32.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter String : " + (i + 1) + " : ");
                s[i] = Console.ReadLine();
            }
            s1 = s;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (s[i] == s[j])
                    {
                        k++;
                    }
                }
                if (k != 1) { c[i] = k; } else { c[i] = 1; }
                s1[i] = s[i];
                k = 0;
                n1++;
            }
            for (int i = 0; i < n1; i++)
            {
                Console.WriteLine("String : " + s1[i] + " Occurance : " + c[i]);
            }
            Console.ReadKey();

        }
        static void Main(string[] args)
        {
            Program p = new Program();
        }
    }
}
