﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac2Sam2
{
    class calculate
    {
        //Square
        public double area(int l)
        {
            return l * l;
        }
        //Triangle
        public double area(double b,double h)
        {
            return 0.5 * b * h;
        }
        //Rectangle
        public float area(float w, float h)
        {
            return w * h;
        }
        //Circle
        public double area(double r)
        {
            return 3.14*r*r;
        }
    };
    class Program
    {
        static void Main(string[] args)
        {
            int ch=0;
            while(ch !=5)
            {
                Console.WriteLine("\n1.Area Of Circle\n2.Area Of Rectangle\n3.Area Of Square\n4.Area Of Triangle\n5.Exit");
                Console.WriteLine("Enter Your Choice : ");
                ch = Int32.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("");
                }
            }
        }
    }
}
