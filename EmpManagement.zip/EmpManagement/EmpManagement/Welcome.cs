﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpManagement
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }
        private void Welcome_Load(object sender, EventArgs e)
        {
            //EmployeeForm empform = new EmployeeForm();
            //Application.Run(empform);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "admin" && txtPassword.Text == "admin")
            {
                EmployeeForm empform = new EmployeeForm();
                empform.WindowState = FormWindowState.Maximized;
                //Application.Run(empform);
                empform.Visible = true;
                empform.Show();
                this.Close();
                this.Dispose();
            }
        }
    }
}
