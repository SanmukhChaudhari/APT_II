﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace EmpManagement
{
    public partial class formAddDepartment : Form
    {
        string deptname;
        OleDbConnection con;
        public formAddDepartment()
        {
            InitializeComponent();
            con = new OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;Data Source=EMS.mdb");
            con.Open();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            deptname = txtDeptname.Text.ToString();
            string query = "INSERT INTO Department (DeptName) VALUES('" + deptname + "')";
            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data saved successfuly...!");
            txtDeptname.Text = "";
        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            EmployeeForm form1 = new EmployeeForm();
            form1.Show();
            form1.WindowState = FormWindowState.Maximized;
            form1.Visible = true;
            
            this.Close();
            this.Dispose();

        }

        private void formAddDepartment_Load(object sender, EventArgs e)
        {

        }
        
    }
}
