﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EmpManagement
{
    public partial class EmployeeForm : Form 
    {
        string empname,address,contactno,salary,birthdate,joiningdate,department,gender;

        private void btnAddDepartment_Click(object sender, EventArgs e)
        {
            formAddDepartment formadddepartment = new formAddDepartment();
            formadddepartment.WindowState = FormWindowState.Maximized;
            EmployeeForm form1 = new EmployeeForm();
            formadddepartment.Show();
            this.Visible = false;
            form1.Close();
            form1.Dispose();
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            clear(); 
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void clear()
        {
            txtEmpname.Text = "";
            txtAddress.Text = "";
            txtContactno.Text = "";
            txtSalary.Text = "";
            cbDepartment.Text = "";
        }
        OleDbConnection con;
        List<string> dept = new List<string>();
        public EmployeeForm() 
        {
            InitializeComponent();
            con = new OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;Data Source=EMS.mdb");
            con.Open();
            string query = "select * from Department;";
            OleDbCommand cmd = new OleDbCommand(query, con);
            OleDbDataReader dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                //dept.Add(dr["DeptName"].ToString());
                cbDepartment.Items.Add(dr["DeptName"].ToString());
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'eMSDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.eMSDataSet.Employee);

        }

        private void txtEmpname_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            empname = txtEmpname.Text.ToString();
            address = txtAddress.Text.ToString();
            contactno = txtContactno.Text.ToString();
            salary = txtSalary.Text.ToString();
            birthdate = dtBirthdate.Value.ToString();
            joiningdate = dtJoiningdate.Value.ToString();
            department = cbDepartment.Text.ToString();
            gender = rbGender.Text.ToString();
            string query = "INSERT INTO Employee (EmpName,Address,ContactNo,Salary,BirthDate,JoiningDate,Department,Gender) VALUES('" + empname + "','" + address + "','" + contactno + "','" + salary + "',#" + birthdate + "#,#" + joiningdate + "#,'" + department + "','" + gender + "')";

            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.ExecuteNonQuery();
            clear();
            MessageBox.Show("Data saved successfuly...!");

        }
    }
}
